/* 
 * File:   main.cpp
 * Author: Connor Kelley
 * Created on March 4, 2015, 8:23 AM
 * Purpose: 4th Homework Problem - Sum of Two Numbers 
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    unsigned short fifty = 50;
    unsigned short cent = 100;
    unsigned short total = cent+fifty;
    
    //Output 
    cout<<"The Sum of Two Numbers Assignment"<<endl;
    cout<<"The sum of "<<fifty<<" and "<<cent<<" is "<<total<<"."<<endl;       
                    
    //Exit Stage Right!
    return 0;
}

