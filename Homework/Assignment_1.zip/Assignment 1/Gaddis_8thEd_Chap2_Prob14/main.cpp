/* 
 * File:   main.cpp
 * Author: Connor Kelley
 * Created on March 4, 2015, 8:23 AM
 * Purpose: 7th Homework Problem - Personal Information 
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    
    //Calculate 
    
    //Output using a single 'cout' statement
    cout<<"Name: Connor Kelley \n"
        <<"Address: 451 Rushmore Dr., Corona, CA, 92879 \n"
        <<"Telephone Number: (909) 732-2684 \n"
        <<"College Major: Computer Science"<<endl;
                   
    //Exit Stage Right!
    return 0;
}

