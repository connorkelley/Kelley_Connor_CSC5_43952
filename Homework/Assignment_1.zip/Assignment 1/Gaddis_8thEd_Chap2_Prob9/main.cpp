/* 
 * File:   main.cpp
 * Author: Connor Kelley
 * Created on March 5, 2015, 10:42 AM
 * Purpose: 10th Homework Problem - Cyborg Data Type Sizes 
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare/Define Variables
       
    //Calculate
    
    //Output 
    cout<<"Cyborg Data Type Sizes Assignment:"<<endl;
    cout<<"The size of the data type \"char\" is "<<sizeof(char)<<"."<<endl;
    cout<<"The size of the data type \"integer\" is "<<sizeof(int)<<"."<<endl;
    cout<<"The size of the data type \"float\" is "<<sizeof(float)<<"."<<endl;
    cout<<"The size of the data type \"double\" is "<<sizeof(double)<<"."<<endl;
    
    //Exit Stage Right!
    return 0;
}

