/* 
 * File:   main.cpp
 * Author: Connor Kelley
 * Created on March 30, 2015, 10:39 AM
 * Purpose: Homework Assignment 4 - 1st Problem - 3. Ocean Levels
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float olvl = 1.5, 
          sum;
    
    //Loop to desired value
    for(int count =1; count <= 25; count++){
        sum = olvl * x;
        cout<<"In year "<<count<<": The ocean will have risen a total of "<<sum<<" millimeters."<<endl;
    }
    
    //Exit Stage Right!
    return 0;
}

