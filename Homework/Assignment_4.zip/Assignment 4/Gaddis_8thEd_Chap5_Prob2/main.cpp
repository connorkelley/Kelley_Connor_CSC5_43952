/* 
 * File:   main.cpp
 * Author: Connor Kelley
 * Created on April 2, 2015, 4:19 PM
 * Purpose: Homework Assignment 4 - 2nd Problem - 2. Characters for the ASCII Codes
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    char ascii;
    
    //Loop to output ASCII code
    for(int x; x <= 127; x++){
        cout<<ascii;
        ascii++;
    }
    
    //Exit Stage Right!
    return 0;
}

